-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : jeu. 17 déc. 2020 à 12:09
-- Version du serveur :  10.5.8-MariaDB
-- Version de PHP : 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `oc_p5_blog`
--

-- --------------------------------------------------------

--
-- Structure de la table `about_me`
--

CREATE TABLE `about_me` (
  `id` int(10) UNSIGNED NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `bio` varchar(255) NOT NULL,
  `profil_picture` varchar(255) NOT NULL,
  `cv_pdf` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `twitter_link` varchar(255) NOT NULL,
  `linkedin_link` varchar(255) NOT NULL,
  `github_link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `about_me`
--

INSERT INTO `about_me` (`id`, `firstname`, `lastname`, `slogan`, `bio`, `profil_picture`, `cv_pdf`, `picture`, `twitter_link`, `linkedin_link`, `github_link`) VALUES
(1, 'Geoffroy', 'Dutot', 'Blog - Développeur web', 'Je suis un jeune alternant. Passionné de développement web ! Particulièrement la partie Back-End ainsi, c\'est pourquoi je suis en cours d\'apprentissage du langage PHP et de différents framework.', 'GDutot.jpeg', 'CV_Geoffroy_Dutot.pdf', 'header-background.jpeg', 'https://twitter.com/dutotgeoffroy', 'https://www.linkedin.com/in/geoffroy-dutot/', 'https://github.com/GeoffroyDutot');

-- --------------------------------------------------------

--
-- Structure de la table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) UNSIGNED NOT NULL,
  `content` varchar(255) NOT NULL,
  `id_post` int(11) UNSIGNED NOT NULL,
  `id_user` int(11) UNSIGNED NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `comment`
--

INSERT INTO `comment` (`id`, `content`, `id_post`, `id_user`, `status`, `created_at`) VALUES
(1, 'Je connaissais déjà Benjamin Code mais je vais regarder les autres merci pour le partage ! ', 3, 3, NULL, '2020-12-15 20:48:23'),
(2, 'Très content de voir cette grande nouvelle version sortit. En espérant qu\'elle augmente la popularité pour ce langage et qu\'il soit moins critiqué..', 1, 3, 'validated', '2020-12-15 20:49:28'),
(3, 'Yes ! Super utile merci pour le partage de ce repo, je me demandais justement comment faire pour rédiger mon Readme. Merci !', 7, 4, 'validated', '2020-12-15 20:51:49'),
(4, 'Je l\'utilise régulièrement en entreprise lorsque que il n\'y a pas Swagger en place pour le projet', 6, 5, 'validated', '2020-12-15 20:53:13'),
(5, 'Je recommande aussi Tailwindcss qui est un framework css. ', 4, 5, NULL, '2020-12-15 20:53:53'),
(6, 'Abonnée ! Merci :) ', 3, 5, 'validated', '2020-12-15 20:54:08'),
(7, 'Un collègue possède ce livre. Il me l\'avait d\'ailleurs aussi recommandé ! Je crois qu\'il va me falloir passer le pas. ', 2, 6, 'validated', '2020-12-15 20:55:27'),
(8, 'Yesss le type Union ! Super pratique ', 1, 6, 'validated', '2020-12-15 20:56:00'),
(9, 'J\'apprends énormément de choses !', 11, 7, 'validated', '2020-12-15 22:21:08'),
(10, 'Je ne connaissais pas c\'est vrai que c\'est pratique ! Merci beaucoup', 6, 7, 'validated', '2020-12-15 22:25:25'),
(11, 'Je connaissais déjà, mais c\'est toujours bien de revoir les bases.', 7, 7, NULL, '2020-12-15 22:26:42'),
(12, 'C\'est vrai que ce framework est très pratique. Je tente d\'essayer de trouver des alternatives à ce framework en ce moment. Je pense regarder du côté de Tailwindcss', 4, 7, 'validated', '2020-12-15 22:27:48'),
(13, 'Très utile !!', 6, 1, NULL, '2020-12-15 22:34:50'),
(14, 'Ça m\'aide beaucoup merci :)', 7, 1, 'validated', '2020-12-15 22:35:13');

-- --------------------------------------------------------

--
-- Structure de la table `post`
--

CREATE TABLE `post` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(50) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `content` text NOT NULL,
  `resume` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `post`
--

INSERT INTO `post` (`id`, `title`, `slug`, `subtitle`, `created_at`, `updated_at`, `content`, `resume`, `picture`, `archived_at`, `is_archived`) VALUES
(1, 'PHP 8 est sorti ! ', 'php-8-est-sorti', 'De meilleures performances grâce au compilateur JIT', '2020-12-14 22:08:44', '2020-12-14 22:09:42', '<p>PHP 8 est une nouvelle version majeure de PHP, sortie le 26 octobre 2020. Il intègre le compilateur JIT qui améliorera les performances. Autre ajouts : le type union<span style=\"font-family: &quot;Source Sans Pro&quot;, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; font-size: 1rem;\">, la syntaxe de classe étendue aux objets, l\'expression throw... et plus encore&nbsp; !<br></span></p><pre class=\"highlight\" style=\"margin-bottom: 0px; padding: 7px 7px 7px 10px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14.44px; line-height: inherit; font-family: inherit; vertical-align: baseline; background: rgb(44, 38, 80); border-radius: 10px; color: rgb(248, 248, 242);\"><code style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: bold; font-stretch: inherit; line-height: inherit; font-family: Consolas, Menlo, Monaco, &quot;Lucida Console&quot;, &quot;Liberation Mono&quot;, &quot;DejaVu Sans Mono&quot;, &quot;Bitstream Vera Sans Mono&quot;, &quot;Courier New&quot;, monospace, serif; vertical-align: baseline; color: rgb(216, 216, 216);\">    <span class=\"cd\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline;\">/**\r\n     * @var int|float $number\r\n     */</span>\r\n    <span class=\"k\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; color: rgb(255, 121, 198);\">private</span> <span class=\"nv\" style=\"margin: 0px; padding: 0px; border: 0px; font-style: italic; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; color: rgb(139, 233, 253);\">$number</span><span class=\"p\" style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; color: rgb(248, 248, 242);\">;</span></code></pre><p><span style=\"font-family: &quot;Source Sans Pro&quot;, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;; font-size: 1rem;\">Vous voulez en savoir plus ? Lisez cet article :&nbsp;</span><a href=\"https://stitcher.io/blog/new-in-php-8\" target=\"_blank\">stitcher.io</a><br>Autres ressources :&nbsp;<br><a href=\"https://www.blogdumoderateur.com/php-8-compilateur-jit-nouvelles-fonctionnalites/\" target=\"_blank\">blogdumoderateur.com</a>&nbsp;<br><a href=\"https://stitcher.io/blog/new-in-php-8\" target=\"_blank\">https://php.watch/versions/8.0/union-types</a>&nbsp;</p>', 'Ça y est PHP 8 est sorti, il a été publié le 26 novembre 2020 et on retiendra surtout l\'ajout du compilateur JIT.', 'php_8_released.png', NULL, 0),
(2, '\"Coder proprement\", conseil de livre', 'coder-proprement-conseil-de-livre', 'Voici une référence de livre afin d\'améliorer vos compétences de dev', '2020-12-14 22:23:19', '2020-12-14 23:00:03', '<p>\"<span style=\"color: rgb(51, 51, 51); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 14px;\">Si un code sale peut fonctionner, il peut également compromettre la pérennité d\'une entreprise de développement de logiciels. Chaque année, du temps et des ressources sont gaspillés à cause d\'un code mal écrit. Toutefois, ce n\'est pas une fatalité.\"&nbsp;</span><a href=\"https://www.amazon.fr/Coder-proprement-Robert-C-Martin/dp/232600227X/ref=asc_df_232600227X/?tag=googshopfr-21&amp;linkCode=df0&amp;hvadid=313794181380&amp;hvpos=&amp;hvnetw=g&amp;hvrand=14047339139744057660&amp;hvpone=&amp;hvptwo=&amp;hvqmt=&amp;hvdev=c&amp;hvdvcmdl=&amp;hvlocint=&amp;hvlocphy=9040912&amp;hvtargid=pla-682551885055&amp;psc=1&amp;tag=&amp;ref=&amp;adgrpid=59863552742&amp;hvpone=&amp;hvptwo=&amp;hvadid=313794181380&amp;hvpos=&amp;hvnetw=g&amp;hvrand=14047339139744057660&amp;hvqmt=&amp;hvdev=c&amp;hvdvcmdl=&amp;hvlocint=&amp;hvlocphy=9040912&amp;hvtargid=pla-682551885055\" target=\"_blank\">\"Coder proprement\"</a>&nbsp;est un livre souvent recommandé qui vous permettra d\'augmenter la qualité de votre code et la lisibilité. Faisant de vous un meilleur développeur, plus votre code sera propre et plus il sera compréhensible par vos collègues. Il sera très utile au débutant mais même les expérimentés peuvent revoir les bases !&nbsp;</p>', 'Je vous conseil le livre \"Coder proprement\", une référence qui vous permettra d\'augmenter la qualité de votre code.', 'coder-proprement.jpg', NULL, 0),
(3, 'Des développeurs Youtubeurs !', 'des-developpeurs-youtubeurs', 'Du contenu vidéo sur le monde du développement en français !', '2020-12-14 22:34:03', '2020-12-14 23:02:06', '<p>Si vous êtes à la recherche de développeurs et créateurs de contenu vidéo voici une petite liste qui pourrait vous intéresser :</p><p><a href=\"https://www.youtube.com/channel/UCWKyakTmFf38Sv0cD8MNzzg\" target=\"_blank\">Les frères codeurs</a><br><a href=\"https://www.youtube.com/channel/UC61GK_nOLSJdzAK5hoR2mJA\" target=\"_blank\">Harry JMG</a><br><a href=\"https://www.youtube.com/channel/UCLOAPb7ATQUs_nDs9ViLcMw\" target=\"_blank\">Benjamin Code</a><br></p>', 'Voici une petite liste de youtubeurs développeurs français ! ', 'header-background.jpeg', NULL, 0),
(4, 'Bootstrap, le plus populaire ', 'bootstrap-le-plus-populaire', 'Un framework css basique mais très utilisé.', '2020-12-14 23:13:46', '2020-12-14 23:27:36', '<p>Très populaire, ce framework permet de mettre en place des designs simplistes et surtout responsive qui est un critère très important pour un site web moderne.</p>', 'Il est le framework le plus utilisé et c\'est aussi le choix de nombreux débutant pour appréhender CSS.', 'bootstrap-icons.png', NULL, 0),
(5, 'Codacy un outil très pratique.', 'codacy-un-outil-tres-pratique', 'Un analyseur de code pour améliorer votre code.', '2020-12-14 23:48:41', NULL, '<p>Il existe plusieurs analyseur de code php comme Code Climate, SonarCube, Codacy. Codacy vous permet d\'analyser la qualité de votre code sur un répertoire comme GitHub. Cela vous permettra de vérifier si votre application n\'a pas de problèmes de sécurités ou encore d\'améliorer votre style de code. Très pratique donc pour améliorer la qualité de votre code et ainsi d\'apprendre aussi de meilleurs méthodes..</p>', 'Codacy est un outil très utile pour optimiser votre code.', 'Codacy.png', NULL, 0),
(6, 'Postman pour débugger votre API ', 'postman-pour-debugger-votre-api', NULL, '2020-12-15 00:03:37', '2020-12-15 00:13:16', '<p>Un outil vraiment populaire et très pratique pour débugger une api en effectuant vos requêtes http.&nbsp;</p>', 'Postman est un outil qui permet de faire et voir le retour de requêtes HTTP  sur nottament des API.', 'postman.jpg', NULL, 0),
(7, 'Personnaliser votre README avec du MARKDOWN', 'personnaliser-votre-readme-avec-du-markdown', NULL, '2020-12-15 00:23:31', NULL, '<p><span style=\"color: rgb(77, 81, 86); font-family: arial, sans-serif; font-size: 14px;\">\"Markdown est un langage de balisage léger créé en 2004 par John Gruber avec l\'aide d\'Aaron Swartz. Elle a été créée dans le but d\'offrir une syntaxe facile à lire et à écrire\" src :&nbsp;</span><a href=\"https://fr.wikipedia.org/wiki/Markdown\" target=\"_blank\">Wikipédia</a><br>Vous en avez déjà probablement rencontrer en effet il est utilisé généralement pour créer les README de vos projets GitHub.</p><p>Vous souhaiteriez personnaliser votre ReadMe pour permettre une meilleure compréhension de votre projet, un tutoriel d\'installation voici les bases du Markdown vous pourrez ainsi sans problème rédiger votre contenu&nbsp; !<br><br><a href=\"https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet\" target=\"_blank\">Bases du Markdown</a><br></p>', 'Vous avez une application ? Vous voulez créer un ReadMe détailler pour ce projet mais vous ne connaissez pas le Markdown ? Je vous partage les ressources qu\'il vous faut.', 'markdown.png', NULL, 0),
(11, 'Le site du zéro !', 'le-site-du-zero', 'Parfait pour devenir développeur.', '2020-12-15 22:17:27', '2020-12-15 22:21:22', '<p>Le site du zéro est très populaire, vous pouvez y apprendre l\'html - css, il y a des nombreux cours sur divers langages de programmation php, javascript. Il y à même un forum pour discuter de nos projets ou poser des questions.</p>', 'Grâce à ce site tu pourras acquérir de nombreuses compétences en programmation !', NULL, '2020-12-15 22:21:22', 1);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) UNSIGNED NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `pseudo` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `profil_picture` varchar(255) DEFAULT NULL,
  `date_registered` datetime NOT NULL,
  `is_deactivated` tinyint(1) NOT NULL DEFAULT 0,
  `reason_deactivation` varchar(255) DEFAULT NULL,
  `deactivated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `pseudo`, `role`, `profil_picture`, `date_registered`, `is_deactivated`, `reason_deactivation`, `deactivated_at`) VALUES
(1, 'jeanne.dupont@gmail.com', '$2y$10$0aJ3IfJDV/VfVCi0EXnqDO4YOO9aJJeuUIKSrcnahVPKD58SEsm9m', 'JeanneD', 'ROLE_USER', '5fd925d153619.png', '2020-12-14 21:46:36', 0, NULL, NULL),
(2, 'dev.blog@gmail.com', '$2y$10$Up5Wa64sEr5CQrfq9MEhf.AAukDvZUbEYgAPd29SU0R9CLam4/9WC', 'DevBlog', 'ROLE_ADMIN', 'rox.png', '2020-12-14 21:49:44', 0, NULL, NULL),
(3, 'robertpoitou@gmail.com', '$2y$10$gWXoD2MqeM46U3dIsAiRwOFz4bVVdeJQlkXdxIM0UNVBdyGZ73h76', 'rob', 'ROLE_USER', NULL, '2020-12-15 20:47:46', 0, NULL, NULL),
(4, 'quentin78@gmail.com', '$2y$10$e34viHtnx1AQZa1tZUZuUOh42yYgUDYnIEGik2bAk0zUFzGw6oM3G', 'Quentinx', 'ROLE_USER', NULL, '2020-12-15 20:50:54', 1, NULL, '2020-12-15 22:28:19'),
(5, 'emmadev56@gmail.com', '$2y$10$RMqZCM4xPjmn0UHaSIR7c.bTjHWFSlb91IU1r/uIQ.b6y6FOBY1vm', 'Emma56', 'ROLE_USER', '5fd927398cacb.png', '2020-12-15 20:52:32', 0, NULL, NULL),
(6, 'alexlegrand@laposte.net', '$2y$10$3wDDz0KpDOvThJs3/Lmboe32fWoDIJIFz0LGqhNfO.c3hOmvSLzre', 'Alex', 'ROLE_USER', '5fd91fafded38.png', '2020-12-15 20:54:40', 0, NULL, NULL),
(7, 'yanngenereux@yahoo.fr', '$2y$10$VRDNgm9sVGv2.DiBhLDlV.Az/Ios31uKoJub7xazZ1Wy1HrQrwRIm', 'Yannou', 'ROLE_USER', NULL, '2020-12-15 22:20:38', 0, NULL, NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `about_me`
--
ALTER TABLE `about_me`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_post` (`id_post`) USING BTREE;

--
-- Index pour la table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `pseudo` (`pseudo`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `about_me`
--
ALTER TABLE `about_me`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `id_post` FOREIGN KEY (`id_post`) REFERENCES `post` (`id`),
  ADD CONSTRAINT `id_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
